//----------------------------------
//File name: URL mongodb Altas(db.js)
//Author's Name: Manvibolreach Ouk
//Student ID: 301224112
//Web App name: Faculty Information
//Date: October 24, 2022
//----------------------------------

module.exports = {
  //local MongoDB deployment ->
  URI: "mongodb+srv://COMP229-F2022-Midterm-301224112:ERsPJ0t5Iwt9uyuz@cluster0.qpmlaui.mongodb.net/faculty_info?retryWrites=true&w=majority",
};
