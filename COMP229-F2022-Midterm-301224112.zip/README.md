# COMP229-F2022-MidTerm Test

## Welcome to the MidTerm Project - the Faculty Informatio App

please use **`npm install`** to install project dependencies
____________________________________________________________________________________________________________________
How to deploy MongoDB on Heroku [MongoDB](https://www.mongodb.com/developer/products/atlas/use-atlas-on-heroku/).